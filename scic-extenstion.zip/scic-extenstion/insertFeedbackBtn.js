function insertFeedback() {
  let markToDeduct = 0;

  let feedback = "";
  let index = 1;
  // console.log(loadFeedback)
  for (const section in loadFeedback) {
    // console.log(section)
    feedback +=
      `
` +
      section +
      `
`;
    for (const req in loadFeedback[section]) {
      // console.log(req)
      const requirement = loadFeedback[section][req];

      if (Object.keys(loadFeedback[section][req]).length > 4) {
        if (!requirement.correct) {
          feedback +=
            `
` +
            index +
            ". ";
          feedback += requirement.description;
          feedback += ` 
&emsp;<strong>→ ${requirement.message}</strong>
`;
          markToDeduct += Number(requirement.number);
        } else {
          let allSubReqOk = true;
          feedback +=
            `
` +
            index +
            ". ";
          feedback += requirement.description;

          for (const subReq in loadFeedback[section][req]) {
            if (subReq.includes("sub_req_")) {
              console.log(subReq, loadFeedback[section][req][subReq]);

              if (!requirement[subReq].correct) {
                feedback += `
&emsp;<strong>→ ${requirement[subReq].message ? requirement[subReq].message : `not okay.`
                  }</strong> `;
                markToDeduct += Number(requirement[subReq].number);
                allSubReqOk = false;
              }
            }
          }
          if (allSubReqOk)
            feedback += ` - ঠিক আছে। 
                  `;
        }
      } else {
        feedback +=
          `
` +
          index +
          ". ";
        feedback += requirement.description;
        if (requirement.correct) {
          if (requirement.number == 0) {
            // feedback += `দারুন হয়েছে।`;
            feedback += ` - ঠিক আছে। 
                          `;
          } else {
            feedback += ` - ঠিক আছে। 
                          `;
          }
        } else {
          if (requirement.number == 0) {
            // feedback += `অপশনাল পার্টটুকু করার চেষ্টা করবেন। তাহলে আপনার প্রজেক্ট অন্যদের তুলনায় আরো ইউনিক হয়ে উঠবে।`;
            feedback += ` 
&emsp;<strong> → ${requirement.message}</strong>
                          `;
          } else {
            feedback += ` 
&emsp;<strong> → ${requirement.message}</strong>
                          `;
            markToDeduct += Number(requirement.number);
          }
        }
      }
      index++;
    }
  }

  const totalMark = Number(document.querySelector(".font-weight-bold.pl-2")?.innerText) || 60;
  let obtainedMark = 0;
  if (totalMark == 60) {
    obtainedMark = 60 - markToDeduct;
  } else if (totalMark == 50) {
    obtainedMark = Math.ceil(50 - (markToDeduct * 50) / 60);
  } else {
    obtainedMark = Math.ceil(30 - markToDeduct / 2);
  }

  console.log(feedback, markToDeduct, obtainedMark);


  feedback += `
এক্সামিনার ফিডব্যাক - ভালো হয়েছে। এভাবে রেগুলার অল্প অল্প করে প্রাকটিস করার চেষ্টা করবেন তাহলে আশা করি আপনার কনফিডেন্স অনেক বেড়ে যাবে যখন কোথাও আপনি ইন্টারভিউ দিবেন।`

  const textArea = document.querySelector(".ql-editor p");
  textArea.innerHTML = feedback;

  const markBox = document.getElementById("Mark");
  // markBox.value = obtainedMark;
  const allP = document.getElementsByClassName("markSuggestions");

  for (const p of allP) {
    markBox.parentNode.removeChild(p);
  }

  const markSuggestion = document.createElement("p");
  // markSuggestion.setAttribute("class", "markSuggestions");
  markSuggestion.className = "m-2 w-50 markSuggestions";
  markSuggestion.innerText = `${obtainedMark} ?`;

  markBox.after(markSuggestion);

  // hide all feedback
  showReqToogleBox = !showReqToogleBox;
  showFeedbackReq(true);
}
